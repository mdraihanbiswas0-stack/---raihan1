#!/usr/bin/env node
/**
 * `npx cap add android` এর পরে চলে। জেনারেট-হওয়া Android প্রজেক্টে বসায়:
 *  - সব দরকারি পারমিশন + queries (TTS / ভয়েস) + অটোফিল সার্ভিস
 *  - নেটিভ জাভা কোড (প্লাগইন, অটোফিল), আইকন, নোটিফিকেশন-আইকন
 *  - সাইনিং কনফিগ, ভার্সন, targetSdk, lint সেটিং
 * বারবার চালালেও নিরাপদ (idempotent)।
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, "..");
const ANDROID = path.join(ROOT, "android");
const OVERLAY = path.join(ROOT, "android-overlay");

const log = (...a) => console.log("[patch]", ...a);
const die = (m) => {
  console.error("[patch] ত্রুটি:", m);
  process.exit(1);
};

if (!fs.existsSync(ANDROID)) die("android ফোল্ডার নেই — আগে `npx cap add android` চালান");

const cfg = JSON.parse(fs.readFileSync(path.join(ROOT, "capacitor.config.json"), "utf8"));
const APP_ID = cfg.appId;
const APP_NAME = cfg.appName;
const VERSION_CODE = parseInt(process.env.VERSION_CODE || "1", 10) || 1;
const VERSION_NAME = process.env.VERSION_NAME || `1.0.${VERSION_CODE}`;
const TARGET_SDK = process.env.TARGET_SDK || "34";

const read = (p) => fs.readFileSync(p, "utf8");
const write = (p, s) => fs.writeFileSync(p, s);

function walk(dir, out = []) {
  for (const f of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, f.name);
    if (f.isDirectory()) walk(p, out);
    else out.push(p);
  }
  return out;
}

/* ---------- ১) জাভা কোড ---------- */
const javaDir = path.join(ANDROID, "app/src/main/java", ...APP_ID.split("."));
fs.mkdirSync(javaDir, { recursive: true });
// পুরনো/ডিফল্ট MainActivity সরিয়ে আমাদেরটা
for (const f of walk(path.join(ANDROID, "app/src/main/java"))) {
  if (path.basename(f) === "MainActivity.java" || path.basename(f) === "MainActivity.kt") fs.unlinkSync(f);
}
for (const f of fs.readdirSync(path.join(OVERLAY, "java"))) {
  const src = read(path.join(OVERLAY, "java", f)).replaceAll("__APP_ID__", APP_ID);
  write(path.join(javaDir, f), src);
}
log("জাভা ফাইল বসেছে →", path.relative(ROOT, javaDir));

/* ---------- ২) রিসোর্স (আইকন, লেআউট, নোটিফিকেশন-আইকন) ---------- */
const resDir = path.join(ANDROID, "app/src/main/res");
for (const f of walk(path.join(OVERLAY, "res"))) {
  const rel = path.relative(path.join(OVERLAY, "res"), f);
  const dest = path.join(resDir, rel);
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.copyFileSync(f, dest);
}
// ডিফল্ট Capacitor-স্প্ল্যাশ ছবি মুছে ফেলা — তার জায়গায় কালো পর্দার মাঝখানে আপনার লোগো (drawable/splash.xml)
try {
  for (const f of walk(resDir)) {
    if (path.basename(f) === "splash.png") fs.unlinkSync(f);
  }
} catch (e) {
  log("স্প্ল্যাশ বদলানো গেল না (সমস্যা নেই):", e.message);
}
// অ্যাপের নাম (বাংলা) — strings.xml
const stringsPath = path.join(resDir, "values/strings.xml");
if (fs.existsSync(stringsPath)) {
  let s = read(stringsPath);
  const esc = APP_NAME.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/'/g, "\\'");
  s = s.replace(/(<string name="app_name">)[^<]*(<\/string>)/, `$1${esc}$2`);
  s = s.replace(/(<string name="title_activity_main">)[^<]*(<\/string>)/, `$1${esc}$2`);
  write(stringsPath, s);
}
// Android 12+ এর সিস্টেম স্প্ল্যাশ: কালো ব্যাকগ্রাউন্ড + লোগো
const stylesPath0 = path.join(resDir, "values/styles.xml");
if (fs.existsSync(stylesPath0)) {
  let st = read(stylesPath0);
  if (!st.includes("jn_splash")) {
    st = st.replace(
      /(<style name="AppTheme\.NoActionBarLaunch"[^>]*SplashScreen[^>]*>)/,
      `$1\n        <!-- jn_splash -->\n        <item name="windowSplashScreenBackground">#000000</item>\n        <item name="windowSplashScreenAnimatedIcon">@mipmap/ic_launcher_foreground</item>`
    );
    write(stylesPath0, st);
  }
}
// স্ট্যাটাস/নেভিগেশন বার কালো
const stylesPath = path.join(resDir, "values/styles.xml");
if (fs.existsSync(stylesPath)) {
  let s = read(stylesPath);
  if (!s.includes("jn_bars")) {
    s = s.replace(
      /(<style name="AppTheme\.NoActionBar"[^>]*>)/,
      `$1\n        <!-- jn_bars -->\n        <item name="android:statusBarColor">#000000</item>\n        <item name="android:navigationBarColor">#000000</item>\n        <item name="android:windowBackground">#000000</item>`
    );
    write(stylesPath, s);
  }
}

/* ---------- ৩) AndroidManifest ---------- */
const manPath = path.join(ANDROID, "app/src/main/AndroidManifest.xml");
let man = read(manPath);

const PERMS = [
  ["android.permission.INTERNET"],
  ["android.permission.ACCESS_NETWORK_STATE"],
  ["android.permission.POST_NOTIFICATIONS"], // নোটিফিকেশন (Android 13+)
  ["android.permission.VIBRATE"],
  ["android.permission.WAKE_LOCK"],
  ["android.permission.RECEIVE_BOOT_COMPLETED"], // রিবুটের পর রিমাইন্ডার ফিরিয়ে আনা
  ["android.permission.SCHEDULE_EXACT_ALARM"], // ঠিক সময়ে রিমাইন্ডার
  ["android.permission.USE_EXACT_ALARM"],
  ["android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"], // ব্যাকগ্রাউন্ডে রিমাইন্ডার না থামা
  ["android.permission.RECORD_AUDIO"], // ভয়েস টাইপিং / "ফ্লো" ভয়েস সহকারী
  ["android.permission.MODIFY_AUDIO_SETTINGS"],
  ["android.permission.USE_BIOMETRIC"], // ফিঙ্গারপ্রিন্ট/ফেস (কী-ফ্লো)
  ["android.permission.USE_FINGERPRINT"],
  ["android.permission.WRITE_EXTERNAL_STORAGE", 'android:maxSdkVersion="28"'],
];
let permXml = "";
for (const [name, extra] of PERMS) {
  if (!man.includes(`"${name}"`)) {
    permXml += `    <uses-permission android:name="${name}"${extra ? " " + extra : ""} />\n`;
  }
}
if (!man.includes("android.hardware.microphone")) {
  permXml += `    <uses-feature android:name="android.hardware.microphone" android:required="false" />\n`;
  permXml += `    <uses-feature android:name="android.hardware.touchscreen" android:required="false" />\n`;
}
if (!man.includes("<queries>")) {
  permXml += `    <queries>
        <intent><action android:name="android.intent.action.TTS_SERVICE" /></intent>
        <intent><action android:name="android.speech.RecognitionService" /></intent>
        <intent><action android:name="android.intent.action.VIEW" /><data android:mimeType="text/calendar" /></intent>
        <intent><action android:name="android.intent.action.SEND" /><data android:mimeType="*/*" /></intent>
        <intent><action android:name="android.intent.action.VIEW" /><data android:scheme="https" /></intent>
        <intent><action android:name="android.intent.action.VIEW" /><data android:scheme="tel" /></intent>
        <intent><action android:name="android.intent.action.VIEW" /><data android:scheme="mailto" /></intent>
    </queries>\n`;
}
if (permXml) man = man.replace(/<application/, permXml + "    <application");

// <application> বৈশিষ্ট্য
function setAttr(tagRe, attr, val) {
  man = man.replace(tagRe, (tag) => {
    const re = new RegExp(`\\s${attr.replace(":", "\\:")}="[^"]*"`);
    if (re.test(tag)) return tag.replace(re, ` ${attr}="${val}"`);
    return tag.replace(/>$/, `\n        ${attr}="${val}">`);
  });
}
setAttr(/<application[^>]*>/, "android:allowBackup", "false");
setAttr(/<application[^>]*>/, "android:hardwareAccelerated", "true");
setAttr(/<application[^>]*>/, "android:usesCleartextTraffic", "false");
setAttr(/<application[^>]*>/, "android:largeHeap", "true");
// MainActivity: কিবোর্ড, পোর্ট্রেট
setAttr(/<activity[^>]*android:name="[^"]*MainActivity"[^>]*>/, "android:windowSoftInputMode", "adjustResize");
setAttr(/<activity[^>]*android:name="[^"]*MainActivity"[^>]*>/, "android:screenOrientation", "portrait");

if (!man.includes("JonakiAutofillService")) {
  const comps = `
        <!-- কী-ফ্লো অটোফিল সার্ভিস (Settings → Autofill service থেকে বাছাই করতে হয়) -->
        <service
            android:name=".JonakiAutofillService"
            android:exported="true"
            android:label="কী-ফ্লো অটোফিল"
            android:permission="android.permission.BIND_AUTOFILL_SERVICE">
            <intent-filter>
                <action android:name="android.service.autofill.AutofillService" />
            </intent-filter>
        </service>
        <activity
            android:name=".AutofillAuthActivity"
            android:excludeFromRecents="true"
            android:exported="false"
            android:theme="@android:style/Theme.Translucent.NoTitleBar" />
`;
  man = man.replace(/<\/application>/, comps + "    </application>");
}
write(manPath, man);
log("AndroidManifest প্যাচ হয়েছে");

/* ---------- ৪) variables.gradle (targetSdk) ---------- */
const varPath = path.join(ANDROID, "variables.gradle");
if (fs.existsSync(varPath)) {
  let v = read(varPath);
  v = v.replace(/targetSdkVersion\s*=\s*\d+/, `targetSdkVersion = ${TARGET_SDK}`);
  write(varPath, v);
  log("targetSdk =", TARGET_SDK);
}

/* ---------- ৫) app/build.gradle (সাইনিং, ভার্সন, lint) ---------- */
const gPath = path.join(ANDROID, "app/build.gradle");
let g = read(gPath);
g = g.replace(/versionCode\s+\d+/, `versionCode ${VERSION_CODE}`);
g = g.replace(/versionName\s+"[^"]*"/, `versionName "${VERSION_NAME}"`);
if (!g.includes("jonaki-signing")) {
  g = g.replace(
    /android\s*\{/,
    `android {
    // jonaki-signing
    signingConfigs {
        jonakiRelease {
            storeFile file(System.getenv("JN_KEYSTORE") ?: "\${rootDir}/../keystore/jonaki-release.jks")
            storePassword System.getenv("JN_STORE_PASS") ?: "jonaki-release"
            keyAlias System.getenv("JN_KEY_ALIAS") ?: "jonaki"
            keyPassword System.getenv("JN_KEY_PASS") ?: "jonaki-release"
        }
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }`
  );
  g = g.replace(/buildTypes\s*\{\s*release\s*\{/, (m) => `${m}\n            signingConfig signingConfigs.jonakiRelease`);
}
write(gPath, g);
log(`build.gradle প্যাচ হয়েছে (versionCode=${VERSION_CODE})`);

/* ---------- ৬) gradle.properties ---------- */
const gpPath = path.join(ANDROID, "gradle.properties");
if (fs.existsSync(gpPath)) {
  let p = read(gpPath);
  if (!/org\.gradle\.jvmargs/.test(p)) p += "\norg.gradle.jvmargs=-Xmx3g -Dfile.encoding=UTF-8\n";
  else p = p.replace(/org\.gradle\.jvmargs=.*/, "org.gradle.jvmargs=-Xmx3g -Dfile.encoding=UTF-8");
  if (!/android\.useAndroidX/.test(p)) p += "android.useAndroidX=true\n";
  write(gpPath, p);
}

log(`সব প্যাচ শেষ ✔ (appId=${APP_ID})`);
