package __APP_ID__;

import android.app.PendingIntent;
import android.app.assist.AssistStructure;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Build;
import android.os.CancellationSignal;
import android.service.autofill.AutofillService;
import android.service.autofill.Dataset;
import android.service.autofill.FillCallback;
import android.service.autofill.FillContext;
import android.service.autofill.FillRequest;
import android.service.autofill.FillResponse;
import android.service.autofill.SaveCallback;
import android.service.autofill.SaveRequest;
import android.text.InputType;
import android.util.Pair;
import android.view.View;
import android.view.autofill.AutofillId;
import android.widget.RemoteViews;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * কী-ফ্লো অটোফিল সার্ভিস: অন্য অ্যাপ/ব্রাউজারের লগইন ফর্মে ইউজারনেম-পাসওয়ার্ড বসায়।
 * প্রতিবার ফোনের স্ক্রিন-লক (পিন/প্যাটার্ন/ফিঙ্গারপ্রিন্ট) দিয়ে যাচাই করে তবেই তথ্য দেয়।
 */
public class JonakiAutofillService extends AutofillService {

    private static final AtomicInteger REQ = new AtomicInteger(1000);

    private static class Parsed {
        AutofillId userId;
        AutofillId passId;
        AutofillId lastText;
        String pkg;
        String web;
    }

    @Override
    public void onFillRequest(FillRequest request, CancellationSignal cancel, FillCallback callback) {
        try {
            List<FillContext> ctx = request.getFillContexts();
            if (ctx == null || ctx.isEmpty()) {
                callback.onSuccess(null);
                return;
            }
            AssistStructure st = ctx.get(ctx.size() - 1).getStructure();
            Parsed p = new Parsed();
            for (int i = 0; i < st.getWindowNodeCount(); i++) {
                parse(st.getWindowNodeAt(i).getRootViewNode(), p, 0);
            }
            if (p.passId == null && p.userId == null) {
                callback.onSuccess(null);
                return;
            }
            if (getPackageName().equals(p.pkg)) {
                callback.onSuccess(null);
                return;
            }
            List<AutofillStore.Entry> all = AutofillStore.load(this);
            if (all.isEmpty()) {
                callback.onSuccess(null);
                return;
            }
            List<AutofillStore.Entry> matches = match(all, p);
            FillResponse.Builder fr = new FillResponse.Builder();
            int n = 0;
            for (AutofillStore.Entry e : matches) {
                if (n >= 4) break;
                String sub = e.user.length() > 0 ? e.user : AutofillStore.hostOf(e.url);
                fr.addDataset(dataset(e.title.length() > 0 ? e.title : sub, sub, sender(e.id, p)));
                n++;
            }
            fr.addDataset(dataset("🔐 কী-ফ্লো ভল্ট", "সব লগইন থেকে বাছুন", sender(null, p)));
            callback.onSuccess(fr.build());
        } catch (Throwable t) {
            callback.onFailure("autofill error");
        }
    }

    @Override
    public void onSaveRequest(SaveRequest request, SaveCallback callback) {
        callback.onSuccess();
    }

    @SuppressWarnings("deprecation")
    private Dataset dataset(String title, String sub, IntentSender sender) {
        RemoteViews rv = new RemoteViews(getPackageName(), R.layout.autofill_item);
        rv.setTextViewText(R.id.af_title, title);
        rv.setTextViewText(R.id.af_sub, sub);
        Dataset.Builder b = new Dataset.Builder(rv);
        b.setAuthentication(sender);
        return b.build();
    }

    private IntentSender sender(String entryId, Parsed p) {
        Intent i = new Intent(this, AutofillAuthActivity.class);
        if (entryId != null) i.putExtra("entry", entryId);
        if (p.userId != null) i.putExtra("user", p.userId);
        if (p.passId != null) i.putExtra("pass", p.passId);
        int flags = PendingIntent.FLAG_CANCEL_CURRENT;
        if (Build.VERSION.SDK_INT >= 31) flags |= PendingIntent.FLAG_MUTABLE;
        return PendingIntent.getActivity(this, REQ.incrementAndGet(), i, flags).getIntentSender();
    }

    /* ---------- ফর্মের ফিল্ড খোঁজা ---------- */

    private void parse(AssistStructure.ViewNode n, Parsed p, int depth) {
        if (n == null || depth > 60) return;
        if (p.pkg == null) {
            String ip = n.getIdPackage();
            if (ip != null && ip.length() > 0) p.pkg = ip;
        }
        String wd = n.getWebDomain();
        if (wd != null && wd.length() > 0) p.web = wd;

        AutofillId id = n.getAutofillId();
        if (id != null && n.getAutofillType() == View.AUTOFILL_TYPE_TEXT) {
            boolean isPass = false;
            boolean isUser = false;
            String[] hints = n.getAutofillHints();
            if (hints != null) {
                for (String h : hints) {
                    if (h == null) continue;
                    if (View.AUTOFILL_HINT_PASSWORD.equals(h)) isPass = true;
                    else if (View.AUTOFILL_HINT_USERNAME.equals(h)
                            || View.AUTOFILL_HINT_EMAIL_ADDRESS.equals(h)
                            || View.AUTOFILL_HINT_PHONE.equals(h)) isUser = true;
                }
            }
            int it = n.getInputType();
            if ((it & InputType.TYPE_MASK_CLASS) == InputType.TYPE_CLASS_TEXT) {
                int v = it & InputType.TYPE_MASK_VARIATION;
                if (v == InputType.TYPE_TEXT_VARIATION_PASSWORD
                        || v == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                        || v == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD) isPass = true;
                else if (v == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
                        || v == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS) isUser = true;
            } else if ((it & InputType.TYPE_MASK_CLASS) == InputType.TYPE_CLASS_NUMBER) {
                if ((it & InputType.TYPE_MASK_VARIATION) == InputType.TYPE_NUMBER_VARIATION_PASSWORD) isPass = true;
            }
            android.view.ViewStructure.HtmlInfo hi = n.getHtmlInfo();
            if (hi != null) {
                String tag = hi.getTag();
                if (tag != null && "input".equalsIgnoreCase(tag) && hi.getAttributes() != null) {
                    for (Pair<String, String> a : hi.getAttributes()) {
                        if (a == null || a.first == null || a.second == null) continue;
                        String k = a.first.toLowerCase(Locale.ROOT);
                        String val = a.second.toLowerCase(Locale.ROOT);
                        if ("type".equals(k)) {
                            if ("password".equals(val)) isPass = true;
                            else if ("email".equals(val) || "tel".equals(val)) isUser = true;
                        } else if ("autocomplete".equals(k)) {
                            if (val.contains("password")) isPass = true;
                            else if (val.contains("username") || val.contains("email")) isUser = true;
                        } else if ("name".equals(k) || "id".equals(k)) {
                            if (val.contains("user") || val.contains("email") || val.contains("login")) isUser = true;
                        }
                    }
                }
            }
            String ide = n.getIdEntry();
            if (ide != null) {
                String l = ide.toLowerCase(Locale.ROOT);
                if (l.contains("pass")) isPass = true;
                else if (l.contains("user") || l.contains("email") || l.contains("login")) isUser = true;
            }
            boolean isText = (it & InputType.TYPE_MASK_CLASS) == InputType.TYPE_CLASS_TEXT || n.getHtmlInfo() != null;
            if (isPass) {
                if (p.passId == null) {
                    p.passId = id;
                    if (p.userId == null && p.lastText != null) p.userId = p.lastText;
                }
            } else if (isUser) {
                if (p.userId == null) p.userId = id;
            } else if (isText && p.passId == null) {
                p.lastText = id;
            }
        }
        int cc = n.getChildCount();
        for (int i = 0; i < cc; i++) parse(n.getChildAt(i), p, depth + 1);
    }

    /* ---------- সাইট/অ্যাপ মেলানো ---------- */

    private List<AutofillStore.Entry> match(List<AutofillStore.Entry> all, Parsed p) {
        List<AutofillStore.Entry> out = new ArrayList<>();
        String web = p.web == null ? "" : p.web.toLowerCase(Locale.ROOT);
        if (web.startsWith("www.")) web = web.substring(4);
        String pkg = p.pkg == null ? "" : p.pkg.toLowerCase(Locale.ROOT);
        String[] toks = pkg.split("\\.");
        for (AutofillStore.Entry e : all) {
            String host = AutofillStore.hostOf(e.url);
            boolean ok = false;
            if (web.length() > 0 && host.length() > 0) {
                ok = web.equals(host) || web.endsWith("." + host) || host.endsWith("." + web);
            }
            if (!ok && web.length() == 0 && pkg.length() > 0) {
                String label = host;
                int d = host.lastIndexOf('.');
                if (d > 0) {
                    String head = host.substring(0, d);
                    int d2 = head.lastIndexOf('.');
                    label = d2 >= 0 ? head.substring(d2 + 1) : head;
                }
                String title = e.title == null ? "" : e.title.toLowerCase(Locale.ROOT);
                for (String t : toks) {
                    if (t.length() < 4 || "android".equals(t) || "mobile".equals(t) || "google".equals(t) && !"google".equals(label)) continue;
                    if ("katana".equals(t) || "orca".equals(t)) continue;
                    if ((label.length() >= 4 && t.contains(label)) || (label.length() >= 4 && label.contains(t))
                            || (title.length() >= 4 && title.contains(t))) {
                        ok = true;
                        break;
                    }
                }
                // ফেসবুক ইত্যাদির প্যাকেজে "facebook" শব্দটা থাকে — তা উপরের শর্তেই ধরা পড়ে
                if (!ok && label.length() >= 4 && pkg.contains(label)) ok = true;
            }
            if (ok) out.add(e);
        }
        return out;
    }
}
