package __APP_ID__;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * অটোফিলের জন্য লগইন-তালিকা ফোনের Android Keystore-এ (AES-256-GCM) এনক্রিপ্ট করে রাখে।
 * চাবি ডিভাইসের বাইরে যায় না। শুধু "অ্যাপে ফিল" চালু থাকলেই এখানে ডেটা থাকে।
 */
final class AutofillStore {

    private static final String PREFS = "jn_autofill";
    private static final String KEY_DATA = "d";
    private static final String ALIAS = "jn_autofill_key_v1";

    static final class Entry {
        String id = "";
        String title = "";
        String url = "";
        String user = "";
        String pass = "";
    }

    private AutofillStore() {
    }

    private static SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (!ks.containsAlias(ALIAS)) {
            KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            kg.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build());
            kg.generateKey();
        }
        return (SecretKey) ks.getKey(ALIAS, null);
    }

    static synchronized void save(Context c, String json) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key());
        byte[] iv = cipher.getIV();
        byte[] ct = cipher.doFinal(json.getBytes(StandardCharsets.UTF_8));
        String v = Base64.encodeToString(iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(ct, Base64.NO_WRAP);
        SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        sp.edit().putString(KEY_DATA, v).apply();
    }

    static synchronized void clear(Context c) {
        try {
            c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_DATA).apply();
        } catch (Throwable ignored) {
        }
    }

    static synchronized List<Entry> load(Context c) {
        List<Entry> out = new ArrayList<>();
        try {
            String v = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_DATA, null);
            if (v == null) return out;
            int i = v.indexOf(':');
            if (i < 0) return out;
            byte[] iv = Base64.decode(v.substring(0, i), Base64.NO_WRAP);
            byte[] ct = Base64.decode(v.substring(i + 1), Base64.NO_WRAP);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, iv));
            String json = new String(cipher.doFinal(ct), StandardCharsets.UTF_8);
            JSONArray a = new JSONArray(json);
            for (int k = 0; k < a.length(); k++) {
                JSONObject o = a.optJSONObject(k);
                if (o == null) continue;
                Entry e = new Entry();
                e.id = o.optString("id", "");
                e.title = o.optString("t", "");
                e.url = o.optString("u", "");
                e.user = o.optString("n", "");
                e.pass = o.optString("p", "");
                if (e.pass.length() > 0 || e.user.length() > 0) out.add(e);
            }
        } catch (Throwable ignored) {
        }
        return out;
    }

    /** ঠিকানা থেকে হোস্ট (www ছাড়া, ছোট হাতের) */
    static String hostOf(String u) {
        if (u == null) return "";
        String s = u.trim().toLowerCase();
        int p = s.indexOf("://");
        if (p >= 0) s = s.substring(p + 3);
        int e = s.length();
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch == '/' || ch == '?' || ch == '#' || ch == ':') {
                e = i;
                break;
            }
        }
        s = s.substring(0, e);
        if (s.startsWith("www.")) s = s.substring(4);
        return s;
    }
}
