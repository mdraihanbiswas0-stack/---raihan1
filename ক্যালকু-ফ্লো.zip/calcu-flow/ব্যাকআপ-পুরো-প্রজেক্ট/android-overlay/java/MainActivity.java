package __APP_ID__;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        // নিজস্ব নেটিভ প্লাগইন (ভয়েস, বায়োমেট্রিক, ফাইল-সেভ, অটোফিল, ক্লিপবোর্ড…)
        registerPlugin(JonakiNativePlugin.class);
        super.onCreate(savedInstanceState);
        try {
            WebView wv = getBridge().getWebView();
            WebSettings s = wv.getSettings();
            // রিমাইন্ডারের শব্দ/ভয়েস গেস্টার ছাড়াই বাজতে পারবে
            s.setMediaPlaybackRequiresUserGesture(false);
            // ফোনের ফন্ট-সাইজ সেটিং অ্যাপের ডিজাইন ভাঙবে না
            s.setTextZoom(100);
            s.setDomStorageEnabled(true);
            s.setDatabaseEnabled(true);
            wv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        } catch (Throwable ignored) {
        }
    }
}
