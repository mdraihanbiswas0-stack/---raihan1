package com.jonaki.search   // <-- আপনার প্রজেক্টের package অনুযায়ী বদলান

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

/** OmniFinder হোম-স্ক্রিন সার্চ বার উইজেট (অ্যাপের সার্চ বারের আদলে)। */
class OmniFinderWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        for (id in ids) {
            val v = RemoteViews(context.packageName, R.layout.omnifinder_widget)
            v.setOnClickPendingIntent(R.id.omni_logo,   pi(context, "search", 0))
            v.setOnClickPendingIntent(R.id.omni_search, pi(context, "search", 1))
            v.setOnClickPendingIntent(R.id.omni_camera, pi(context, "camera", 2))
            v.setOnClickPendingIntent(R.id.omni_voice,  pi(context, "voice", 3))
            manager.updateAppWidget(id, v)
        }
    }

    private fun pi(ctx: Context, mode: String, code: Int): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java).apply {
            action = "com.jonaki.search.OMNI_WIDGET"
            putExtra(EXTRA_MODE, mode)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(
            ctx, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    companion object { const val EXTRA_MODE = "omni_mode" }
}
