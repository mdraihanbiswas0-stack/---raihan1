# OmniFinder হোম-স্ক্রিন উইজেট

অ্যাপের সার্চ বারের আদলে: জোনাকি লোগো | "OmniFinder-এ খুঁজুন…" | ক্যামেরা | ভয়েস

## বসানোর ধাপ
1. `res/` ফোল্ডারের সব ফাইল আপনার Android প্রজেক্টের `app/src/main/res/` এ কপি করুন।
2. `kotlin/OmniFinderWidget.kt` → `app/src/main/java/<package>/` এ রাখুন (package লাইন মিলিয়ে নিন)।
3. `manifest_snippet.xml` এর `<receiver>` `<application>` এর ভেতরে বসান।
4. `kotlin/MainActivity_patch.kt.txt` এর কোড MainActivity-তে যোগ করুন।
5. `OmniFinder.html` আপনার অ্যাপের assets/webDir এ বসিয়ে বিল্ড করুন।
6. ফোনে হোম স্ক্রিনে ফাঁকা জায়গায় লং-প্রেস → Widgets → "OmniFinder সার্চ"।

## কীভাবে কাজ করে
উইজেটের ট্যাপ → MainActivity (extra `omni_mode`) → `window.__omniOpen('search'|'camera'|'voice')` (OmniFinder.html এ যোগ করা)।
