# Smart Dialer (Android)
Contents: app/ (Android project), server/ (caller-ID/spam server, Python).

## Build the APK
1. Install Android Studio. File > Open > select this SmartDialer folder. Wait for Gradle Sync.
2. Build > Build Bundle(s)/APK(s) > Build APK(s).
3. APK: app/build/outputs/apk/debug/app-debug.apk  (copy to the phone and install).
4. First run: allow all permissions and choose "Smart Dialer" as the default phone app.

## Server (optional, for online caller ID / spam)
    cd server && python3 server.py
Then in the app: Tools > Server URL = http://<server-ip>:8080

## Design
- Custom line-icon set (app/src/main/res/drawable/ic_*.xml), teal/ink palette with light and dark themes.
- Floating pill navigation, avatar initials, card-style lists, redesigned call screen with call timer.
- Long-press the app icon for shortcuts: Audio Record, Keypad, Recents, Contacts.
