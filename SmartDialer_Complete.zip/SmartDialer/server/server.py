"""Caller-ID / spam report server. Pure Python 3, no dependencies.
Run:  python3 server.py            (port 8080)
Env:  PORT, DB_PATH, API_KEY (optional shared key sent as X-Api-Key), SPAM_THRESHOLD (default 3)
"""
import json, os, re, sqlite3, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

DB_PATH = os.environ.get("DB_PATH", "dialer.db")
API_KEY = os.environ.get("API_KEY", "")
THRESHOLD = int(os.environ.get("SPAM_THRESHOLD", "3"))


def norm(n):
    return re.sub(r"\D", "", n or "")[-10:]


def db():
    c = sqlite3.connect(DB_PATH)
    c.execute("""CREATE TABLE IF NOT EXISTS reports(
        number TEXT NOT NULL, device TEXT NOT NULL,
        name TEXT NOT NULL DEFAULT '', spam INTEGER NOT NULL DEFAULT 0,
        ts INTEGER NOT NULL, PRIMARY KEY(number, device))""")
    return c


def lookup(number):
    n = norm(number)
    c = db()
    spam, total = c.execute(
        "SELECT COALESCE(SUM(spam),0), COUNT(*) FROM reports WHERE number=?", (n,)).fetchone()
    row = c.execute(
        "SELECT name, COUNT(*) k FROM reports WHERE number=? AND name<>'' "
        "GROUP BY name ORDER BY k DESC LIMIT 1", (n,)).fetchone()
    c.close()
    return {"number": n, "name": row[0] if row else None,
            "spam_reports": spam, "total_reports": total, "is_spam": spam >= THRESHOLD}


def report(number, device, name, spam):
    n = norm(number)
    if len(n) < 5 or not device:
        return False
    c = db()
    c.execute("""INSERT INTO reports(number, device, name, spam, ts) VALUES(?,?,?,?,?)
        ON CONFLICT(number, device) DO UPDATE SET
          name=CASE WHEN excluded.name<>'' THEN excluded.name ELSE name END,
          spam=MAX(spam, excluded.spam), ts=excluded.ts""",
              (n, device[:64], (name or "")[:60], 1 if spam else 0, int(time.time())))
    c.commit(); c.close()
    return True


class H(BaseHTTPRequestHandler):
    def _send(self, code, obj):
        b = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def _auth(self):
        if API_KEY and self.headers.get("X-Api-Key") != API_KEY:
            self._send(401, {"error": "unauthorized"}); return False
        return True

    def do_GET(self):
        u = urlparse(self.path)
        if u.path == "/health":
            return self._send(200, {"ok": True})
        if u.path == "/lookup" and self._auth():
            num = parse_qs(u.query).get("number", [""])[0]
            return self._send(200, lookup(num))
        if u.path != "/lookup":
            self._send(404, {"error": "not found"})

    def do_POST(self):
        if urlparse(self.path).path != "/report":
            return self._send(404, {"error": "not found"})
        if not self._auth():
            return
        try:
            n = int(self.headers.get("Content-Length", "0"))
            d = json.loads(self.rfile.read(min(n, 4096)))
        except Exception:
            return self._send(400, {"error": "bad json"})
        ok = report(d.get("number"), d.get("device"), d.get("name"), bool(d.get("spam")))
        self._send(200 if ok else 400, {"ok": ok})


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8080"))
    print(f"Listening on :{port}")
    ThreadingHTTPServer(("0.0.0.0", port), H).serve_forever()
