# Dialer server
    python3 server.py
App > Tools > Server URL:  http://<server-ip>:8080   (use HTTPS via a reverse proxy in production)
Optional: API_KEY=secret python3 server.py   (then put the same key in the app's Server key field)
Endpoints: GET /lookup?number=...   POST /report {"number","device","name","spam"}   GET /health
A number is flagged spam after SPAM_THRESHOLD (default 3) different devices report it.
