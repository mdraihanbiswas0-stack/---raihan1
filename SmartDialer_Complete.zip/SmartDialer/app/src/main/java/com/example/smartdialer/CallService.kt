package com.example.smartdialer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import androidx.core.app.NotificationCompat

class CallService : InCallService() {

    private val cb = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) = handle(call, state)
    }

    override fun onCallAdded(call: Call) {
        val num = call.details.handle?.schemeSpecificPart ?: ""

        // Blocked number -> reject silently, no UI
        if (call.state == Call.STATE_RINGING && Blocklist.isBlocked(this, num)) {
            call.reject(false, null)
            return
        }

        CallManager.call = call
        CallManager.service = this
        CallManager.number.value = num
        CallManager.name.value = Contacts.name(this, num)
        CallManager.spam.value = Blocklist.isSpam(this, num)
        CallManager.onlineName.value = null
        CallManager.spamReports.intValue = 0
        call.registerCallback(cb)
        handle(call, call.state)
        if (num.isNotEmpty()) lookupOnline(call, num)

        if (call.state == Call.STATE_RINGING) showIncoming(num, CallManager.name.value)
        startActivity(Intent(this, CallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    override fun onCallRemoved(call: Call) {
        if (call != CallManager.call) return
        call.unregisterCallback(cb)
        cancelIncoming()
        RecordingService.stop(this)   // call ended -> stop and save automatically
        CallManager.clear()
    }

    private fun handle(call: Call, state: Int) {
        CallManager.state.intValue = state
        if (state != Call.STATE_RINGING) cancelIncoming()
        when (state) {
            Call.STATE_ACTIVE -> {          // call answered -> start recording
                if (Prefs.autoSpeaker(this)) setAudioRoute(CallAudioState.ROUTE_SPEAKER)
                if (Prefs.autoRecord(this)) RecordingService.start(this, CallManager.number.value)
            }
            Call.STATE_DISCONNECTED -> RecordingService.stop(this)
        }
    }

    private fun showIncoming(num: String, name: String?) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("incoming", "Incoming calls", NotificationManager.IMPORTANCE_HIGH))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, CallActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(this, "incoming")
            .setSmallIcon(android.R.drawable.sym_call_incoming)
            .setContentTitle(name ?: num)
            .setContentText(if (CallManager.spam.value) "⚠ Suspected spam" else "Incoming call")
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pi)
            .setFullScreenIntent(pi, true)
            .setOngoing(true)
            .build()
        nm.notify(2, n)
    }

    /** Online caller-ID / spam lookup (only if a server URL is set in Tools). */
    private fun lookupOnline(call: Call, num: String) {
        Thread {
            val r = Api.lookup(this, num) ?: return@Thread
            Handler(Looper.getMainLooper()).post {
                if (CallManager.call != call) return@post
                r.name?.let { CallManager.onlineName.value = it }
                CallManager.spamReports.intValue = r.spamReports
                if (r.isSpam) {
                    CallManager.spam.value = true
                    if (Prefs.autoRejectSpam(this) && call.state == Call.STATE_RINGING)
                        call.reject(false, null)
                }
            }
        }.start()
    }

    private fun cancelIncoming() =
        getSystemService(NotificationManager::class.java).cancel(2)
}
