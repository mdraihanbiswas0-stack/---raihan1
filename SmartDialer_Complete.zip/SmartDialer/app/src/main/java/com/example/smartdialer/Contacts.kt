package com.example.smartdialer

import android.content.ContentProviderOperation
import android.content.Context
import android.net.Uri
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.ContactsContract.CommonDataKinds.StructuredName
import androidx.compose.runtime.mutableIntStateOf

data class Contact(val name: String, val number: String)

/** Bumped when the app resumes or a contact is saved, so lists reload from the phone. */
object Refresh { val tick = mutableIntStateOf(0) }

object Contacts {
    /** Reads from the phone's own contacts database (same data as the default Contacts app). */
    fun all(c: Context): List<Contact> {
        val out = mutableListOf<Contact>()
        try {
            c.contentResolver.query(
                Phone.CONTENT_URI,
                arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER),
                null, null, Phone.DISPLAY_NAME + " ASC"
            )?.use { cur ->
                while (cur.moveToNext())
                    out += Contact(cur.getString(0) ?: "", cur.getString(1) ?: "")
            }
        } catch (_: SecurityException) {}
        return out.distinctBy { it.name + Blocklist.norm(it.number) }
    }

    /** Saves straight into the phone's contacts database; the default Contacts app shows it. */
    fun add(c: Context, name: String, number: String): Boolean {
        val ops = ArrayList<ContentProviderOperation>()
        ops += ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
            .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
            .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null).build()
        ops += ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
            .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
            .withValue(ContactsContract.Data.MIMETYPE, StructuredName.CONTENT_ITEM_TYPE)
            .withValue(StructuredName.DISPLAY_NAME, name).build()
        ops += ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
            .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
            .withValue(ContactsContract.Data.MIMETYPE, Phone.CONTENT_ITEM_TYPE)
            .withValue(Phone.NUMBER, number)
            .withValue(Phone.TYPE, Phone.TYPE_MOBILE).build()
        return try {
            c.contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
            Refresh.tick.intValue++
            true
        } catch (e: Exception) { false }
    }

    fun name(c: Context, number: String): String? {
        if (number.isBlank()) return null
        return try {
            val uri = Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            c.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME),
                null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (_: SecurityException) { null }
    }
}
