package com.example.smartdialer

import android.telecom.Call
import android.telecom.InCallService
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf

object CallManager {
    var call: Call? = null
    var service: InCallService? = null
    val state = mutableIntStateOf(Call.STATE_NEW)
    val number = mutableStateOf("")
    val name = mutableStateOf<String?>(null)
    val onlineName = mutableStateOf<String?>(null)
    val spamReports = mutableIntStateOf(0)
    val spam = mutableStateOf(false)

    fun clear() {
        call = null
        state.intValue = Call.STATE_DISCONNECTED
    }
}
