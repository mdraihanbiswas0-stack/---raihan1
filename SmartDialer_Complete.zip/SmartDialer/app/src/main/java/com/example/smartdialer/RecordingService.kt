package com.example.smartdialer

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.text.SimpleDateFormat
import java.util.*

class RecordingService : Service() {
    private var recorder: MediaRecorder? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> start(intent.getStringExtra("number") ?: "unknown")
            ACTION_STOP -> { stopRecording(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
        }
        return START_NOT_STICKY
    }

    private fun start(number: String) {
        if (recorder != null) return
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("rec", "Call recording", NotificationManager.IMPORTANCE_LOW)
        )
        val n = NotificationCompat.Builder(this, "rec")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle(if (Prefs.hideIndicator(this)) "Call in progress" else "Recording call")
            .setContentText(if (Prefs.hideIndicator(this)) "" else number)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)

        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val clean = number.filter { it.isDigit() || it == '+' }.ifEmpty { "unknown" }
        val file = java.io.File(Recordings.dir(this), "REC_${ts}_$clean.m4a")
        try {
            recorder = (if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()).apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(128000)
                setAudioSamplingRate(44100)
                setOutputFile(file.absolutePath)
                prepare()
                start()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            recorder = null
            file.delete()
        }
    }

    private fun stopRecording() {
        try { recorder?.stop() } catch (_: Exception) {}
        recorder?.release()
        recorder = null
    }

    override fun onDestroy() { stopRecording(); super.onDestroy() }

    companion object {
        const val ACTION_START = "START"
        const val ACTION_STOP = "STOP"
        fun start(c: Context, number: String) =
            c.startForegroundService(Intent(c, RecordingService::class.java)
                .setAction(ACTION_START).putExtra("number", number))
        fun stop(c: Context) =
            c.startService(Intent(c, RecordingService::class.java).setAction(ACTION_STOP))
    }
}
