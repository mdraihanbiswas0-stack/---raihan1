package com.example.smartdialer

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Light = lightColorScheme(
    primary = Color(0xFF0E7C7B), onPrimary = Color.White,
    primaryContainer = Color(0xFFD2F1EE), onPrimaryContainer = Color(0xFF00302F),
    secondary = Color(0xFF5B6B8C), onSecondary = Color.White,
    tertiary = Color(0xFF1FAA59), onTertiary = Color.White,
    background = Color(0xFFF1F5F6), onBackground = Color(0xFF10191B),
    surface = Color.White, onSurface = Color(0xFF10191B),
    surfaceVariant = Color(0xFFE3EAEC), onSurfaceVariant = Color(0xFF55656A),
    outline = Color(0xFFC5D0D3), outlineVariant = Color(0xFFDCE4E6),
    error = Color(0xFFE5484D), onError = Color.White,
    errorContainer = Color(0xFFFDE4E4), onErrorContainer = Color(0xFF7A1115),
    surfaceContainer = Color.White, surfaceContainerHigh = Color.White,
    surfaceContainerHighest = Color(0xFFE9EFF0), surfaceContainerLow = Color.White,
    surfaceContainerLowest = Color.White,
)

private val Dark = darkColorScheme(
    primary = Color(0xFF5ADBD0), onPrimary = Color(0xFF00302F),
    primaryContainer = Color(0xFF124645), onPrimaryContainer = Color(0xFFC9F4F0),
    secondary = Color(0xFFA9B9DB), onSecondary = Color(0xFF1A2540),
    tertiary = Color(0xFF4BDB86), onTertiary = Color(0xFF00210E),
    background = Color(0xFF0B1113), onBackground = Color(0xFFE6EEF0),
    surface = Color(0xFF131C1F), onSurface = Color(0xFFE6EEF0),
    surfaceVariant = Color(0xFF1C282B), onSurfaceVariant = Color(0xFF93A5AA),
    outline = Color(0xFF2A3A3E), outlineVariant = Color(0xFF223033),
    error = Color(0xFFFF8A8D), onError = Color(0xFF3B0A0C),
    errorContainer = Color(0xFF4A1F21), onErrorContainer = Color(0xFFFFD9DA),
    surfaceContainer = Color(0xFF131C1F), surfaceContainerHigh = Color(0xFF1A2528),
    surfaceContainerHighest = Color(0xFF1F2C30), surfaceContainerLow = Color(0xFF131C1F),
    surfaceContainerLowest = Color(0xFF0B1113),
)

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp), small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(20.dp), large = RoundedCornerShape(28.dp),
    extraLarge = RoundedCornerShape(36.dp),
)

private val AppType = Typography(
    titleLarge = TextStyle(fontSize = 22.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Medium),
    bodyLarge = TextStyle(fontSize = 16.sp),
    bodyMedium = TextStyle(fontSize = 14.sp),
    labelLarge = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.Medium),
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) Dark else Light,
        shapes = AppShapes, typography = AppType
    ) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { content() }
    }
}
