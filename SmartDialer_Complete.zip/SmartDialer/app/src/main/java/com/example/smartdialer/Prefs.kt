package com.example.smartdialer

import android.content.Context
import java.util.UUID

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("settings", Context.MODE_PRIVATE)
    fun autoRecord(c: Context) = sp(c).getBoolean("auto_record", true)
    fun autoSpeaker(c: Context) = sp(c).getBoolean("auto_speaker", true)
    fun hideIndicator(c: Context) = sp(c).getBoolean("hide_indicator", false)
    fun online(c: Context) = sp(c).getBoolean("online", true)
    fun autoRejectSpam(c: Context) = sp(c).getBoolean("auto_reject_spam", false)
    fun serverUrl(c: Context) = sp(c).getString("server_url", "") ?: ""
    fun apiKey(c: Context) = sp(c).getString("api_key", "") ?: ""
    fun set(c: Context, key: String, v: Boolean) = sp(c).edit().putBoolean(key, v).apply()
    fun setStr(c: Context, key: String, v: String) = sp(c).edit().putString(key, v).apply()
    fun deviceId(c: Context): String =
        sp(c).getString("device_id", null) ?: UUID.randomUUID().toString().also { setStr(c, "device_id", it) }
}
