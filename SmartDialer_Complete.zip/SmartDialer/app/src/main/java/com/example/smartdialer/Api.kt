package com.example.smartdialer

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class LookupResult(val name: String?, val spamReports: Int, val isSpam: Boolean)

object Api {
    private fun base(c: Context) = Prefs.serverUrl(c).trim().trimEnd('/')

    private fun open(c: Context, url: String, method: String): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 3000
            readTimeout = 3000
            Prefs.apiKey(c).takeIf { it.isNotBlank() }?.let { setRequestProperty("X-Api-Key", it) }
        }

    /** Blocking. Call from a background thread. */
    fun lookup(c: Context, number: String): LookupResult? {
        val b = base(c)
        if (b.isEmpty() || !Prefs.online(c)) return null
        return try {
            val conn = open(c, "$b/lookup?number=${URLEncoder.encode(number, "UTF-8")}", "GET")
            val j = JSONObject(conn.inputStream.bufferedReader().readText())
            LookupResult(
                if (j.isNull("name")) null else j.getString("name"),
                j.optInt("spam_reports"), j.optBoolean("is_spam"))
        } catch (e: Exception) { null }
    }

    /** Fire-and-forget. */
    fun report(c: Context, number: String, spam: Boolean, name: String? = null) {
        val b = base(c)
        if (b.isEmpty() || !Prefs.online(c)) return
        val app = c.applicationContext
        Thread {
            try {
                val conn = open(app, "$b/report", "POST")
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                val body = JSONObject().put("number", number).put("device", Prefs.deviceId(app))
                    .put("spam", spam).put("name", name ?: "")
                conn.outputStream.use { it.write(body.toString().toByteArray()) }
                conn.responseCode
            } catch (_: Exception) {}
        }.start()
    }
}
