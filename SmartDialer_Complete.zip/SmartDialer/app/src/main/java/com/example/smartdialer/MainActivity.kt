package com.example.smartdialer

import android.Manifest
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.Settings
import android.telecom.TelecomManager
import android.text.format.DateUtils
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DateFormat
import java.util.Date

class MainActivity : ComponentActivity() {

    private val target = mutableStateOf<String?>(null)
    private val missing = mutableStateOf<List<String>>(emptyList())
    private val isDefault = mutableStateOf(true)
    private val skipped = mutableStateOf(false)

    private val roleLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { recheck() }
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        recheck()
        if (!isDefault.value) requestDialerRole()
    }

    private fun required(): List<String> = buildList {
        add(Manifest.permission.CALL_PHONE)
        add(Manifest.permission.READ_PHONE_STATE)
        add(Manifest.permission.READ_CALL_LOG)
        add(Manifest.permission.READ_CONTACTS)
        add(Manifest.permission.WRITE_CONTACTS)
        add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }

    private fun recheck() {
        missing.value = required().filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        isDefault.value = getSystemService(RoleManager::class.java).isRoleHeld(RoleManager.ROLE_DIALER)
    }

    private fun askPermissions() {
        if (missing.value.isNotEmpty()) permLauncher.launch(missing.value.toTypedArray())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        target.value = intent?.getStringExtra("open")
        recheck()
        // Ask for everything as soon as the app opens
        if (missing.value.isNotEmpty()) askPermissions()
        else if (!isDefault.value) requestDialerRole()

        setContent {
            AppTheme {
                if ((missing.value.isEmpty() && isDefault.value) || skipped.value) {
                    App(target.value) { target.value = null }
                } else {
                    SetupScreen(
                        missing = missing.value,
                        isDefault = isDefault.value,
                        onPerms = { askPermissions() },
                        onRole = { requestDialerRole() },
                        onSettings = {
                            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.fromParts("package", packageName, null)))
                        },
                        onSkip = { skipped.value = true })
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        target.value = intent.getStringExtra("open")
    }

    override fun onResume() {
        super.onResume()
        Refresh.tick.intValue++   // reload contacts changed in other apps
        recheck()                 // pick up changes made in system settings
    }

    private fun requestDialerRole() {
        val rm = getSystemService(RoleManager::class.java)
        if (rm.isRoleAvailable(RoleManager.ROLE_DIALER) && !rm.isRoleHeld(RoleManager.ROLE_DIALER))
            roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER))
    }
}

fun placeCall(c: Context, number: String) {
    if (number.isBlank()) return
    c.getSystemService(TelecomManager::class.java)
        .placeCall(Uri.fromParts("tel", number, null), Bundle())
}

/* ---------------------------------------------------------------- setup */

@Composable
fun StatusRow(ok: Boolean, text: String) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(26.dp).clip(CircleShape).background(if (ok) cs.primaryContainer else cs.errorContainer),
            contentAlignment = Alignment.Center) {
            Ic(if (ok) R.drawable.ic_check else R.drawable.ic_close,
                tint = if (ok) cs.primary else cs.error, size = 16.dp)
        }
        Spacer(Modifier.width(12.dp))
        Text(text, fontSize = 16.sp)
    }
}

@Composable
fun SetupScreen(
    missing: List<String>, isDefault: Boolean,
    onPerms: () -> Unit, onRole: () -> Unit, onSettings: () -> Unit, onSkip: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(28.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(96.dp).clip(CircleShape).background(cs.primary), contentAlignment = Alignment.Center) {
            Ic(R.drawable.ic_phone, tint = cs.onPrimary, size = 44.dp)
        }
        Spacer(Modifier.height(24.dp))
        Text("Set up Smart Dialer", fontSize = 26.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Text("To make and receive calls, record them and show contacts, the app needs the following.",
            color = cs.onSurfaceVariant, textAlign = TextAlign.Center)
        Spacer(Modifier.height(24.dp))
        StatusRow(missing.isEmpty(), if (missing.isEmpty()) "Permissions granted" else "Permissions needed (${missing.size})")
        StatusRow(isDefault, if (isDefault) "Default phone app" else "Not the default phone app")
        Spacer(Modifier.height(24.dp))
        if (missing.isNotEmpty()) {
            Button(onClick = onPerms, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(26.dp)) {
                Text("Allow permissions")
            }
            TextButton(onClick = onSettings) { Text("Permission blocked? Open app settings") }
        }
        if (!isDefault) {
            Button(onClick = onRole, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(26.dp)) {
                Text("Set as default phone app")
            }
        }
        TextButton(onClick = onSkip) { Text("Continue anyway") }
    }
}

/* ------------------------------------------------------------------ app */

@Composable
fun NavBar(tab: Int, onTab: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val items = listOf(
        R.drawable.ic_keypad to "Keypad", R.drawable.ic_recents to "Recents",
        R.drawable.ic_contacts to "Contacts", R.drawable.ic_tools to "Tools")
    Surface(
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
        shape = RoundedCornerShape(32.dp), color = cs.surface, tonalElevation = 2.dp, shadowElevation = 8.dp
    ) {
        Row(Modifier.padding(6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            items.forEachIndexed { i, (ic, label) ->
                val sel = tab == i
                Row(
                    Modifier.weight(if (sel) 1.7f else 1f).height(52.dp).clip(RoundedCornerShape(26.dp))
                        .background(if (sel) cs.primaryContainer else Color.Transparent)
                        .clickable { onTab(i) },
                    horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
                ) {
                    Ic(ic, tint = if (sel) cs.onPrimaryContainer else cs.onSurfaceVariant)
                    if (sel) {
                        Spacer(Modifier.width(6.dp))
                        Text(label, color = cs.onPrimaryContainer, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
fun App(target: String?, consumed: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    var screen by remember { mutableStateOf<String?>(null) }
    BackHandler(screen != null) { screen = null }
    // App shortcut (long-press on app icon) -> open the requested tab/screen
    LaunchedEffect(target) {
        when (target) {
            "keypad" -> { screen = null; tab = 0 }
            "recents" -> { screen = null; tab = 1 }
            "contacts" -> { screen = null; tab = 2 }
            "tools" -> { screen = null; tab = 3 }
            "rec", "blocked", "spam" -> screen = target
        }
        if (target != null) consumed()
    }

    when (screen) {
        "rec" -> RecordingsScreen { screen = null }
        "blocked" -> NumberListScreen("Blocked numbers", "blocked", R.drawable.ic_block) { screen = null }
        "spam" -> NumberListScreen("Spam list", "spam", R.drawable.ic_spam) { screen = null }
        else -> Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = { NavBar(tab) { tab = it } }
        ) { pad ->
            Box(Modifier.padding(pad)) {
                when (tab) {
                    0 -> Keypad()
                    1 -> Recents()
                    2 -> ContactsTab()
                    else -> Tools { screen = it }
                }
            }
        }
    }
}

/* --------------------------------------------------------------- keypad */

@Composable
fun Keypad() {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var num by remember { mutableStateOf("") }
    val label = remember(num) { if (num.length >= 3) Contacts.name(ctx, num) else null }
    val letters = mapOf('2' to "ABC", '3' to "DEF", '4' to "GHI", '5' to "JKL",
        '6' to "MNO", '7' to "PQRS", '8' to "TUV", '9' to "WXYZ", '0' to "+")
    Column(
        Modifier.fillMaxSize().padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom
    ) {
        Text(label ?: " ", color = cs.primary, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        Text(num.ifEmpty { " " }, fontSize = 38.sp, fontWeight = FontWeight.Light, letterSpacing = 2.sp,
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(vertical = 10.dp))
        Spacer(Modifier.height(6.dp))
        listOf("123", "456", "789", "*0#").forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.padding(vertical = 6.dp)) {
                row.forEach { ch ->
                    Box(Modifier.size(68.dp).clip(CircleShape).background(cs.surface).clickable { num += ch },
                        contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(ch.toString(), fontSize = 26.sp)
                            Text(letters[ch] ?: " ", fontSize = 9.sp, color = cs.onSurfaceVariant, letterSpacing = 1.sp)
                        }
                    }
                }
            }
        }
        Row(Modifier.padding(top = 10.dp, bottom = 18.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Spacer(Modifier.size(68.dp))
            CircleBtn(R.drawable.ic_phone, "Call", { placeCall(ctx, num) }, cs.tertiary, Color.White, size = 68.dp)
            Box(Modifier.size(68.dp).clip(CircleShape).clickable { if (num.isNotEmpty()) num = num.dropLast(1) },
                contentAlignment = Alignment.Center) {
                Ic(R.drawable.ic_backspace, tint = cs.onSurfaceVariant, size = 26.dp)
            }
        }
    }
}

/* -------------------------------------------------------------- recents */

data class LogItem(val number: String, val name: String?, val type: Int, val date: Long)

@Composable
fun Recents() {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var list by remember { mutableStateOf<List<LogItem>>(emptyList()) }
    LaunchedEffect(Refresh.tick.intValue) {
        list = withContext(Dispatchers.IO) {
            val out = mutableListOf<LogItem>()
            try {
                ctx.contentResolver.query(CallLog.Calls.CONTENT_URI,
                    arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE, CallLog.Calls.DATE),
                    null, null, "${CallLog.Calls.DATE} DESC")?.use { c ->
                    while (c.moveToNext() && out.size < 200)
                        out += LogItem(c.getString(0) ?: "", c.getString(1), c.getInt(2), c.getLong(3))
                }
            } catch (_: SecurityException) {}
            out
        }
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Title("Recents")
        if (list.isEmpty()) EmptyState(R.drawable.ic_recents, "No calls yet")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
            items(list) { item ->
                var menu by remember { mutableStateOf(false) }
                val shown = item.name?.takeIf { it.isNotBlank() } ?: item.number.ifEmpty { "Unknown" }
                val (arrow, tint, word) = when (item.type) {
                    CallLog.Calls.INCOMING_TYPE -> Triple(R.drawable.ic_in, cs.primary, "Incoming")
                    CallLog.Calls.OUTGOING_TYPE -> Triple(R.drawable.ic_out, cs.onSurfaceVariant, "Outgoing")
                    CallLog.Calls.MISSED_TYPE -> Triple(R.drawable.ic_in, cs.error, "Missed")
                    else -> Triple(R.drawable.ic_in, cs.onSurfaceVariant, "Call")
                }
                Surface(shape = RoundedCornerShape(22.dp), color = cs.surface, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.clickable { placeCall(ctx, item.number) }.padding(start = 12.dp, top = 10.dp, bottom = 10.dp, end = 4.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Avatar(shown)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(shown, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    color = if (item.type == CallLog.Calls.MISSED_TYPE) cs.error else cs.onSurface,
                                    modifier = Modifier.weight(1f, fill = false))
                                if (Blocklist.isSpam(ctx, item.number)) {
                                    Spacer(Modifier.width(6.dp))
                                    Pill("Spam", cs.errorContainer, cs.error)
                                }
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Ic(arrow, tint = tint, size = 14.dp)
                                Spacer(Modifier.width(4.dp))
                                Text("$word · " + DateUtils.getRelativeTimeSpanString(item.date, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS),
                                    fontSize = 12.sp, color = cs.onSurfaceVariant)
                            }
                        }
                        Box {
                            IconButton(onClick = { menu = true }) { Ic(R.drawable.ic_more, tint = cs.onSurfaceVariant) }
                            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                DropdownMenuItem(text = { Text("Call") }, onClick = { menu = false; placeCall(ctx, item.number) })
                                DropdownMenuItem(text = { Text("Add to contacts") }, onClick = {
                                    menu = false
                                    ctx.startActivity(Intent(Intent.ACTION_INSERT_OR_EDIT).apply {
                                        type = ContactsContract.Contacts.CONTENT_ITEM_TYPE
                                        putExtra(ContactsContract.Intents.Insert.PHONE, item.number)
                                    })
                                })
                                DropdownMenuItem(text = { Text("Block") }, onClick = { menu = false; Blocklist.add(ctx, "blocked", item.number) })
                                DropdownMenuItem(text = { Text("Mark as spam") }, onClick = {
                                    menu = false; Blocklist.add(ctx, "spam", item.number); Api.report(ctx, item.number, true)
                                })
                            }
                        }
                    }
                }
            }
        }
    }
}

/* ------------------------------------------------------------- contacts */

@Composable
fun ContactsTab() {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var all by remember { mutableStateOf<List<Contact>>(emptyList()) }
    var q by remember { mutableStateOf("") }
    var favs by remember { mutableStateOf(Blocklist.get(ctx, "fav")) }
    var showAdd by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    var newNumber by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    // Reloads from the phone's contacts whenever the app resumes or a contact is saved
    LaunchedEffect(Refresh.tick.intValue) { all = withContext(Dispatchers.IO) { Contacts.all(ctx) } }
    val shown = remember(all, q, favs) {
        val f = if (q.isBlank()) all else all.filter { it.name.contains(q, true) || it.number.contains(q) }
        f.sortedByDescending { Blocklist.norm(it.number) in favs }   // favorites first
    }

    if (showAdd) {
        AlertDialog(
            onDismissRequest = { showAdd = false },
            shape = RoundedCornerShape(28.dp),
            title = { Text("New contact") },
            text = {
                Column {
                    OutlinedTextField(newName, { newName = it }, label = { Text("Name") }, singleLine = true,
                        shape = RoundedCornerShape(16.dp))
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(newNumber, { newNumber = it }, label = { Text("Phone number") }, singleLine = true,
                        shape = RoundedCornerShape(16.dp))
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val n = newName.trim(); val p = newNumber.trim()
                    if (n.isEmpty() || p.isEmpty()) {
                        Toast.makeText(ctx, "Enter name and number", Toast.LENGTH_SHORT).show()
                    } else {
                        scope.launch {
                            val ok = withContext(Dispatchers.IO) { Contacts.add(ctx, n, p) }
                            Toast.makeText(ctx,
                                if (ok) "Saved to phone contacts" else "Could not save (allow Contacts permission)",
                                Toast.LENGTH_SHORT).show()
                            if (ok) { showAdd = false; newName = ""; newNumber = "" }
                        }
                    }
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Cancel") } }
        )
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Title("Contacts")
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextField(
                value = q, onValueChange = { q = it }, singleLine = true,
                placeholder = { Text("Search contacts") },
                leadingIcon = { Ic(R.drawable.ic_search, tint = cs.onSurfaceVariant, size = 20.dp) },
                shape = RoundedCornerShape(28.dp), modifier = Modifier.weight(1f),
                colors = TextFieldDefaults.colors(
                    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                    focusedContainerColor = cs.surface, unfocusedContainerColor = cs.surface)
            )
            Spacer(Modifier.width(10.dp))
            CircleBtn(R.drawable.ic_plus, "Add contact", { showAdd = true }, cs.primary, cs.onPrimary, size = 52.dp, iconSize = 24.dp)
        }
        Spacer(Modifier.height(12.dp))
        if (shown.isEmpty()) EmptyState(R.drawable.ic_contacts, "No contacts found")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
            items(shown) { c ->
                val key = Blocklist.norm(c.number)
                val fav = key in favs
                Surface(shape = RoundedCornerShape(22.dp), color = cs.surface, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.clickable { placeCall(ctx, c.number) }.padding(start = 12.dp, top = 10.dp, bottom = 10.dp, end = 4.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Avatar(c.name.ifEmpty { c.number })
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(c.name, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(c.number, fontSize = 12.sp, color = cs.onSurfaceVariant)
                        }
                        IconButton(onClick = {
                            if (fav) Blocklist.remove(ctx, "fav", key) else Blocklist.add(ctx, "fav", c.number)
                            favs = Blocklist.get(ctx, "fav")
                        }) {
                            Ic(if (fav) R.drawable.ic_star_fill else R.drawable.ic_star,
                                tint = if (fav) cs.primary else cs.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

/* ---------------------------------------------------------------- tools */

@Composable
fun ToolCard(icon: Int, title: String, sub: String, container: Color, content: Color, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.heightIn(min = 128.dp).clip(RoundedCornerShape(26.dp)).background(container)
            .clickable(onClick = onClick).padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Box(Modifier.size(44.dp).clip(CircleShape).background(content.copy(alpha = 0.14f)), contentAlignment = Alignment.Center) {
            Ic(icon, tint = content)
        }
        Spacer(Modifier.height(14.dp))
        Column {
            Text(title, fontWeight = FontWeight.SemiBold, color = content, fontSize = 16.sp)
            Text(sub, fontSize = 12.sp, color = content.copy(alpha = 0.75f))
        }
    }
}

@Composable
fun SettingRow(icon: Int, title: String, sub: String? = null, checked: Boolean, onChange: (Boolean) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(cs.primaryContainer), contentAlignment = Alignment.Center) {
            Ic(icon, tint = cs.onPrimaryContainer, size = 20.dp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Medium)
            if (sub != null) Text(sub, fontSize = 12.sp, color = cs.onSurfaceVariant)
        }
        Switch(checked, onChange)
    }
}

@Composable
fun Tools(open: (String) -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var autoRec by remember { mutableStateOf(Prefs.autoRecord(ctx)) }
    var autoSpk by remember { mutableStateOf(Prefs.autoSpeaker(ctx)) }
    var hideInd by remember { mutableStateOf(Prefs.hideIndicator(ctx)) }
    var online by remember { mutableStateOf(Prefs.online(ctx)) }
    var autoSpam by remember { mutableStateOf(Prefs.autoRejectSpam(ctx)) }
    var url by remember { mutableStateOf(Prefs.serverUrl(ctx)) }
    var key by remember { mutableStateOf(Prefs.apiKey(ctx)) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        Title("Tools")
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ToolCard(R.drawable.ic_mic, "Audio Record", "Play and share calls",
                cs.primaryContainer, cs.onPrimaryContainer, Modifier.weight(1f)) { open("rec") }
            ToolCard(R.drawable.ic_block, "Blocked", "Auto-rejected numbers",
                cs.errorContainer, cs.onErrorContainer, Modifier.weight(1f)) { open("blocked") }
        }
        Spacer(Modifier.height(12.dp))
        ToolCard(R.drawable.ic_spam, "Spam list", "Numbers you reported",
            cs.surface, cs.onSurface, Modifier.fillMaxWidth()) { open("spam") }

        SectionLabel("Calls")
        Surface(shape = RoundedCornerShape(26.dp), color = cs.surface, modifier = Modifier.fillMaxWidth()) {
            Column {
                SettingRow(R.drawable.ic_mic, "Auto record calls", "Starts when a call is answered",
                    autoRec) { autoRec = it; Prefs.set(ctx, "auto_record", it) }
                SettingRow(R.drawable.ic_speaker, "Auto speaker on answer", "Helps capture both voices",
                    autoSpk) { autoSpk = it; Prefs.set(ctx, "auto_speaker", it) }
                SettingRow(R.drawable.ic_eye_off, "Silent recording mode", "Hide the label on the call screen",
                    hideInd) { hideInd = it; Prefs.set(ctx, "hide_indicator", it) }
            }
        }

        SectionLabel("Online caller ID")
        Surface(shape = RoundedCornerShape(26.dp), color = cs.surface, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(bottom = 14.dp)) {
                SettingRow(R.drawable.ic_globe, "Caller ID and spam database", "Sends the number to your server",
                    online) { online = it; Prefs.set(ctx, "online", it) }
                SettingRow(R.drawable.ic_spam, "Auto-reject known spam", null,
                    autoSpam) { autoSpam = it; Prefs.set(ctx, "auto_reject_spam", it) }
                OutlinedTextField(url, { url = it; Prefs.setStr(ctx, "server_url", it) },
                    label = { Text("Server URL, e.g. http://192.168.0.5:8080") }, singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp))
                OutlinedTextField(key, { key = it; Prefs.setStr(ctx, "api_key", it) },
                    label = { Text("Server key (optional)") }, singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp))
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun NumberListScreen(title: String, key: String, icon: Int, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var list by remember { mutableStateOf(Blocklist.get(ctx, key).toList()) }
    var input by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        ScreenHeader(title, onBack)
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 10.dp)) {
            OutlinedTextField(input, { input = it }, label = { Text("Phone number") }, singleLine = true,
                shape = RoundedCornerShape(20.dp), modifier = Modifier.weight(1f))
            Spacer(Modifier.width(10.dp))
            CircleBtn(R.drawable.ic_plus, "Add", {
                Blocklist.add(ctx, key, input); input = ""; list = Blocklist.get(ctx, key).toList()
            }, cs.primary, cs.onPrimary, size = 52.dp, iconSize = 24.dp)
        }
        if (list.isEmpty()) EmptyState(icon, "Nothing here yet")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list) { n ->
                Surface(shape = RoundedCornerShape(22.dp), color = cs.surface, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(start = 14.dp, top = 6.dp, bottom = 6.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Ic(icon, tint = cs.error, size = 22.dp)
                        Spacer(Modifier.width(12.dp))
                        Text(n, modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium)
                        IconButton(onClick = {
                            Blocklist.remove(ctx, key, n); list = Blocklist.get(ctx, key).toList()
                        }) { Ic(R.drawable.ic_trash, tint = cs.onSurfaceVariant) }
                    }
                }
            }
        }
    }
}

/* ----------------------------------------------------------- recordings */

@Composable
fun RecordingsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var files by remember { mutableStateOf(Recordings.list(ctx)) }
    val player = remember { AudioPlayer() }
    DisposableEffect(Unit) { onDispose { player.stop() } }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        ScreenHeader("Audio Record", onBack)
        Spacer(Modifier.height(8.dp))
        if (files.isEmpty()) EmptyState(R.drawable.ic_mic, "No recordings yet")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
            items(files, key = { it.absolutePath }) { f: File ->
                val number = f.nameWithoutExtension.split("_").drop(3).joinToString("_")
                val who = remember(f) { Contacts.name(ctx, number) ?: number.ifEmpty { "Unknown" } }
                val playing = player.current == f
                Surface(shape = RoundedCornerShape(24.dp),
                    color = if (playing) cs.primaryContainer else cs.surface, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(start = 12.dp, top = 10.dp, bottom = 10.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        CircleBtn(if (playing) R.drawable.ic_pause else R.drawable.ic_play, "Play",
                            { player.toggle(f) }, cs.primary, cs.onPrimary, size = 46.dp, iconSize = 22.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(who, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
                                .format(Date(f.lastModified())) + " · ${f.length() / 1024} KB",
                                fontSize = 12.sp, color = cs.onSurfaceVariant)
                        }
                        IconButton(onClick = {
                            val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
                            ctx.startActivity(Intent.createChooser(
                                Intent(Intent.ACTION_SEND).setType("audio/mp4")
                                    .putExtra(Intent.EXTRA_STREAM, uri)
                                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Share"))
                        }) { Ic(R.drawable.ic_share, tint = cs.onSurfaceVariant) }
                        IconButton(onClick = {
                            if (player.current == f) player.stop()
                            f.delete(); files = Recordings.list(ctx)
                        }) { Ic(R.drawable.ic_trash, tint = cs.error) }
                    }
                }
            }
        }
    }
}
