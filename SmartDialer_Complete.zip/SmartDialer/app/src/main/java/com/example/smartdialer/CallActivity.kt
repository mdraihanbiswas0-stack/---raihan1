package com.example.smartdialer

import android.os.Bundle
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.VideoProfile
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

class CallActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppTheme { CallScreen { finish() } } }
    }
}

@Composable
fun ToggleCircle(icon: Int, label: String, on: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        CircleBtn(icon, label, onClick,
            container = if (on) cs.primary else cs.surface,
            content = if (on) cs.onPrimary else cs.onSurface, size = 64.dp, iconSize = 26.dp)
        Spacer(Modifier.height(6.dp))
        Text(label, fontSize = 12.sp, color = cs.onSurfaceVariant)
    }
}

@Composable
fun CallScreen(onEnd: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val state = CallManager.state.intValue
    val number = CallManager.number.value
    val name = CallManager.name.value
    val online = CallManager.onlineName.value
    var spam by CallManager.spam
    var muted by remember { mutableStateOf(false) }
    var speaker by remember { mutableStateOf(false) }
    var seconds by remember { mutableIntStateOf(0) }
    val call = CallManager.call

    LaunchedEffect(state) {
        if (state == Call.STATE_DISCONNECTED) onEnd()
        if (state == Call.STATE_ACTIVE) {
            val t0 = System.currentTimeMillis()
            while (true) {
                seconds = ((System.currentTimeMillis() - t0) / 1000).toInt()
                delay(500)
            }
        }
    }

    val title = name ?: online ?: number.ifEmpty { "Unknown" }
    val status = when (state) {
        Call.STATE_RINGING -> "Incoming call"
        Call.STATE_DIALING, Call.STATE_CONNECTING -> "Calling…"
        Call.STATE_ACTIVE -> "%02d:%02d".format(seconds / 60, seconds % 60)
        Call.STATE_HOLDING -> "On hold"
        else -> ""
    }
    val recording = state == Call.STATE_ACTIVE && Prefs.autoRecord(ctx) && !Prefs.hideIndicator(ctx)

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(cs.primaryContainer, cs.background)))) {
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(top = 40.dp)) {
                Avatar(title, 112.dp)
                Spacer(Modifier.height(20.dp))
                Text(title, fontSize = 30.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)
                if (name != null || online != null) Text(number, color = cs.onSurfaceVariant)
                if (name == null && online != null) Text("Community caller ID", fontSize = 12.sp, color = cs.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                Text(status, fontSize = 18.sp, color = cs.onSurfaceVariant)
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (recording) Pill("● Recording", cs.errorContainer, cs.error)
                    if (spam) Pill(
                        "Suspected spam" + (CallManager.spamReports.intValue.takeIf { it > 0 }?.let { " ($it)" } ?: ""),
                        cs.errorContainer, cs.error)
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                if (state == Call.STATE_ACTIVE) {
                    Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                        ToggleCircle(R.drawable.ic_mic_off, "Mute", muted) {
                            muted = !muted
                            CallManager.service?.setMuted(muted)
                        }
                        ToggleCircle(R.drawable.ic_speaker, "Speaker", speaker) {
                            speaker = !speaker
                            CallManager.service?.setAudioRoute(
                                if (speaker) CallAudioState.ROUTE_SPEAKER else CallAudioState.ROUTE_EARPIECE)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                }
                if (number.isNotEmpty()) {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        if (!spam) TextButton(onClick = {
                            Blocklist.add(ctx, "spam", number); spam = true
                            Api.report(ctx, number, true)
                        }) {
                            Ic(R.drawable.ic_spam, size = 18.dp)
                            Spacer(Modifier.width(6.dp)); Text("Report spam")
                        }
                        TextButton(onClick = {
                            Blocklist.add(ctx, "blocked", number)
                            call?.disconnect()
                        }) {
                            Ic(R.drawable.ic_block, size = 18.dp)
                            Spacer(Modifier.width(6.dp)); Text("Block number")
                        }
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(64.dp), modifier = Modifier.padding(bottom = 36.dp)) {
                if (state == Call.STATE_RINGING) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircleBtn(R.drawable.ic_phone_end, "Decline", { call?.reject(false, null) },
                            cs.error, Color.White, size = 72.dp)
                        Spacer(Modifier.height(6.dp)); Text("Decline", fontSize = 13.sp, color = cs.onSurfaceVariant)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircleBtn(R.drawable.ic_phone, "Answer", { call?.answer(VideoProfile.STATE_AUDIO_ONLY) },
                            cs.tertiary, Color.White, size = 72.dp)
                        Spacer(Modifier.height(6.dp)); Text("Answer", fontSize = 13.sp, color = cs.onSurfaceVariant)
                    }
                } else {
                    CircleBtn(R.drawable.ic_phone_end, "End call", { call?.disconnect() },
                        cs.error, Color.White, size = 76.dp)
                }
            }
        }
    }
}
