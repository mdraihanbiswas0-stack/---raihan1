package com.example.smartdialer

import android.content.Context

/** Local blocked / spam lists. key = "blocked" or "spam" */
object Blocklist {
    private fun sp(c: Context) = c.getSharedPreferences("lists", Context.MODE_PRIVATE)
    fun norm(n: String) = n.filter { it.isDigit() }.takeLast(10)

    fun get(c: Context, key: String): Set<String> =
        sp(c).getStringSet(key, emptySet())?.toSet() ?: emptySet()

    fun add(c: Context, key: String, n: String) {
        val v = norm(n); if (v.isEmpty()) return
        sp(c).edit().putStringSet(key, get(c, key) + v).apply()
    }

    fun remove(c: Context, key: String, n: String) =
        sp(c).edit().putStringSet(key, get(c, key) - n).apply()

    fun isBlocked(c: Context, n: String) = norm(n).isNotEmpty() && norm(n) in get(c, "blocked")
    fun isSpam(c: Context, n: String) = norm(n).isNotEmpty() && norm(n) in get(c, "spam")
}
