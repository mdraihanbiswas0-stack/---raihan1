package com.example.smartdialer

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Custom line icon from res/drawable. */
@Composable
fun Ic(res: Int, modifier: Modifier = Modifier, tint: Color = LocalContentColor.current, size: Dp = 24.dp) {
    Icon(painterResource(res), contentDescription = null, modifier = modifier.size(size), tint = tint)
}

@Composable
fun CircleBtn(
    icon: Int, desc: String, onClick: () -> Unit,
    container: Color, content: Color, size: Dp = 64.dp, iconSize: Dp = 28.dp
) {
    Box(
        Modifier.size(size).clip(CircleShape).background(container)
            .clickable(onClickLabel = desc, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Ic(icon, tint = content, size = iconSize) }
}

private val avatarColors = listOf(
    Color(0xFF0E9AA7), Color(0xFFE5484D), Color(0xFF7B61FF),
    Color(0xFFF59E0B), Color(0xFF1FAA59), Color(0xFFEC4899)
)

@Composable
fun Avatar(name: String, size: Dp = 46.dp) {
    val c = avatarColors[(name.hashCode() and 0x7fffffff) % avatarColors.size]
    val letter = name.trim().firstOrNull { it.isLetter() }
    Box(Modifier.size(size).clip(CircleShape).background(c.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
        if (letter != null)
            Text(letter.uppercase(), color = c, fontSize = (size.value * 0.4f).sp, fontWeight = FontWeight.SemiBold)
        else Ic(R.drawable.ic_contacts, tint = c, size = size * 0.5f)
    }
}

@Composable
fun Pill(text: String, container: Color, content: Color) {
    Box(Modifier.clip(RoundedCornerShape(50)).background(container).padding(horizontal = 10.dp, vertical = 4.dp)) {
        Text(text, color = content, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun Title(text: String) {
    Text(text, fontSize = 30.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.5).sp,
        modifier = Modifier.padding(start = 4.dp, top = 18.dp, bottom = 14.dp))
}

@Composable
fun SectionLabel(text: String) {
    Text(text, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 6.dp, top = 22.dp, bottom = 8.dp))
}

@Composable
fun ScreenHeader(title: String, onBack: () -> Unit) {
    Row(Modifier.padding(top = 14.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        CircleBtn(R.drawable.ic_back, "Back", onBack, MaterialTheme.colorScheme.surface,
            MaterialTheme.colorScheme.onSurface, size = 42.dp, iconSize = 22.dp)
        Spacer(Modifier.width(14.dp))
        Text(title, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun EmptyState(icon: Int, text: String) {
    Column(Modifier.fillMaxWidth().padding(48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(72.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center) {
            Ic(icon, tint = MaterialTheme.colorScheme.onSurfaceVariant, size = 32.dp)
        }
        Spacer(Modifier.height(14.dp))
        Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
