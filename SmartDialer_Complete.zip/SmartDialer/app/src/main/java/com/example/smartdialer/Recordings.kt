package com.example.smartdialer

import android.content.Context
import android.media.MediaPlayer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File

object Recordings {
    fun dir(c: Context): File =
        File(c.getExternalFilesDir(null), "AudioRecord").also { it.mkdirs() }

    fun list(c: Context): List<File> =
        dir(c).listFiles { f -> f.extension == "m4a" }?.sortedByDescending { it.lastModified() }
            ?: emptyList()
}

class AudioPlayer {
    private var mp: MediaPlayer? = null
    var current by mutableStateOf<File?>(null)
        private set

    fun toggle(f: File) {
        if (current == f) { stop(); return }
        stop()
        mp = MediaPlayer().apply {
            setDataSource(f.absolutePath)
            prepare()
            start()
            setOnCompletionListener { stop() }
        }
        current = f
    }

    fun stop() {
        mp?.release()
        mp = null
        current = null
    }
}
